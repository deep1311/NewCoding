import React from 'react'
import styles from './inputs.module.css'

const index = () => {
  return (
    <div>
      <input type='text' placeholder='Enter Your name'/>
    </div>
  )
}

export default index
