import React from 'react'
import styles from './modal.module.css'

const index = () => {
  return (
    <div>
      Modal
    </div>
  )
}

export default index
