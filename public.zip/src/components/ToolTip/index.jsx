import React from 'react'
import styles from './toolTip.module.css'

const index = () => {
  return (
    <div>
      ToolTip
    </div>
  )
}

export default index
