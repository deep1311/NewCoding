import React from 'react'
import styles from './sidebar.module.css'

const Sidebar = () => {
    return (
        <div className={styles.root}>
            sidebar
        </div>
    )
}

export default Sidebar
