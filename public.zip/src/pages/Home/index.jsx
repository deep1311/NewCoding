import React from 'react'
import styles from './home.module.css'
import { Header, Footer, Sidebar } from '@/layout'

const index = () => {
  return (
    <div className={styles.root}>

      Home Page


    </div>
  )
}

export default index
